$(document).ready(function() {
    $("#accordion").accordion( {
        active: false,
        collapsible: true,
        heightStyle: 'content'
    });
});