// method for slideshow plugin
$(document).ready(function() {
    $('#slideshow').cycle({
        fx: 'fade' // fade picture slideshow
    });

});