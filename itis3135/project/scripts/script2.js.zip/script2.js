// method for bxslider plugin
$(document).ready(function() {
$("#slider").bxSlider({
    slideWidth: 500, // for slideWidth
    slideMargin: 20, // for slideMargin
    randomStart:true, // to check randomStart
    moveSlides:1, // moveSlides 1 by 1
    captions:true, // to show image captions
    pagerType: 'full' // pagerType


});
});