// method for accordion widget
$(document).ready(function() {
   $("#accordion").accordion({
      collapsible: true, // to show collapse
      active: false // active
   });
});